
/* $Log: xklsyn.c,v $
 * Revision 1.3  1999/02/18 22:18:08  vkapur
 * none
 *
 * Revision 1.2  1998/07/17 08:06:04  krishna
 * Added RCS header.
 * */


#include "xklsyn.h"
