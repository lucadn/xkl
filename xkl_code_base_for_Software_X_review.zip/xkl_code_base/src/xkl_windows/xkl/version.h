/*
*    VERSION.H  - Displayed XKL version
*/

#define VERSION "3.2"		/* xkl version */
#define DATE "02/21/23"		/* date released */

